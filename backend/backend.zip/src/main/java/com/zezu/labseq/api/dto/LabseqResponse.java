package com.zezu.labseq.api.dto;

public record LabseqResponse(long n, String value) { }
